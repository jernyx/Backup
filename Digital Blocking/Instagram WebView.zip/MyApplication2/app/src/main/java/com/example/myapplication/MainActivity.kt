package com.example.myapplication

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.BLACK

        // 1. Request Android 13+ Notification Permission
        checkNotificationPermission()

        webView = WebView(this)
        setContentView(webView)

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        // Allow the website to play notification sounds
        settings.mediaPlaybackRequiresUserGesture = false

        // 2. Handle Website Permission Requests (The "Bridge")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                // Grant all requested permissions (Notifications, Camera, etc.)
                runOnUiThread {
                    request.grant(request.resources)
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectCSS(view)
                hideSharedContainerBlock(view)
                hideMainPageContent(view)
                hideExplorePostParents(view)
                blockNotificationsUI(view)
                blockNoteElement(view)
                blockDirectLikesText(view)
                disableVideoScroll(view)
                blockSuggestedForYou(view)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                view?.loadUrl(request?.url.toString())
                return true
            }
        }

        webView.loadUrl("https://www.instagram.com")
    }

    // New Function: Specifically for Android 13+ (API 33)
    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }
    }

    // --- YOUR EXISTING JAVASCRIPT/CSS INJECTION METHODS BELOW ---

    private fun injectCSS(view: WebView?) {
        val css = """
            [data-visualcompletion="ignore-dynamic"] a[href*="/reels/"] {
                display: none !important;
                visibility: hidden !important;
            }
            [aria-haspopup="menu"] {
                display: none !important;
                visibility: hidden !important;
            }
            [href="/explore/people/"] {
                display: none !important;
                visibility: hidden !important;
            }
            a[href="/jernejstrukelj/followers/"] {
                display: none !important;
                visibility: hidden !important;
            }
            a[href*="threads.com"] {
                display: none !important;
                visibility: hidden !important;
            }
            [style*="height: auto; overflow: hidden auto;"] {
                display: none !important;
                visibility: hidden !important;
            }
            [aria-label="Like"] {
                display: none !important;
                visibility: hidden !important;
            }
            [aria-label="Unlike"] {
                display: none !important;
                visibility: hidden !important;
            }
            div:has(> div > svg[aria-label="Repost"]) {
                display: none !important;
                visibility: hidden !important;
            }
            [data-pagelet="IGDInboxThreadListScrollableAreaPagelet"] > div:nth-of-type(1) {
                display: none !important;
                visibility: hidden !important;
            }
            [href*="/your_activity/interactions"] {
                display: none !important;
                visibility: hidden !important;
            }
            div:has(> svg[aria-label="Notifications"]) + div {
                display: none !important;
                visibility: hidden !important;
            }
            [role="tablist"] {
                display: none !important;
                visibility: hidden !important;            
            }
            [style*="display: flex; flex-direction: column; padding-bottom: 0px; padding-top: 0px; position: relative;"] {
                display: none !important;
                visibility: hidden !important;            
            }
            div:has(> [style="--x-height: 230px;"] div[role="presentation"] ul > li) {
                display: none !important;
                visibility: hidden !important;            
            }
            div:has(> div[data-visualcompletion="ignore"] div[style="--x-width: 100%;"] svg[aria-label="Close"]) {
                display: none !important;
                visibility: hidden !important;            
            }
            video{
                display: none !important;
                visibility: hidden !important;            
            }
        """.trimIndent()

        val js = "var style = document.createElement('style'); style.innerHTML = `$css`; document.head.appendChild(style);"
        view?.evaluateJavascript(js, null)
    }

    private fun hideMainPageContent(view: WebView?) {
        val js = """
            (function() {
                function isMainPage() { return window.location.pathname === "/"; }
                function apply() {
                    if (!isMainPage()) return;
                    const main = document.querySelector('main');
                    if (main) {
                        Array.from(main.children).forEach(child => {
                            if (!child.dataset.permanentlyHidden) {
                                child.style.setProperty("display", "none", "important");
                                child.style.setProperty("visibility", "hidden", "important");
                                child.dataset.permanentlyHidden = "true";
                            }
                        });
                    }
                }
                apply();
                const observer = new MutationObserver((mutations) => {
                    if (isMainPage() && mutations.some(m => m.addedNodes.length > 0)) apply();
                });
                observer.observe(document.body, { childList: true, subtree: true });
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun hideExplorePostParents(view: WebView?) {
        val js = """
            (function() {
                function isExplorePage() { return window.location.pathname.startsWith("/explore"); }
                function apply() {
                    if (!isExplorePage()) return;
                    const target = document.querySelector('main > div:nth-of-type(1)');
                    if (!target) return;
                    const searchInput = document.querySelector('input[aria-label="Search input"]');
                    let isSearching = window.location.pathname.includes('/search');
                    if (searchInput && (document.activeElement === searchInput || searchInput.value.trim() !== '')) isSearching = true;
                    if (isSearching) {
                        target.style.display = ""; target.style.visibility = ""; target.dataset.hiddenByScript = "false";
                    } else {
                        target.style.setProperty("display", "none", "important");
                        target.style.setProperty("visibility", "hidden", "important");
                        target.dataset.hiddenByScript = "true";
                    }
                }
                const observer = new MutationObserver(apply);
                observer.observe(document.body, { childList: true, subtree: true });
                setInterval(apply, 300);
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun blockNotificationsUI(view: WebView?) {
        val js = """
            (function() {
                function isNotificationsPage() { return window.location.pathname.startsWith("/notifications"); }
                function apply() {
                    if (!isNotificationsPage()) return;
                    document.querySelectorAll('h4').forEach(el => { el.style.display = "none"; });
                }
                const observer = new MutationObserver(apply);
                observer.observe(document.body, { childList: true, subtree: true });
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun blockNoteElement(view: WebView?) {
        val js = """
            (function() {
                function isTargetProfile() { return window.location.pathname.startsWith("/jernejstrukelj"); }
                function block() {
                    if (!isTargetProfile()) return;
                    document.querySelectorAll('div, span').forEach(el => {
                        if (el.textContent.trim() === "Note...") {
                            let btn = el.closest('div[role="button"]');
                            if (btn) btn.style.display = "none";
                        }
                    });
                }
                const observer = new MutationObserver(block);
                observer.observe(document.body, { childList: true, subtree: true });
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun blockDirectLikesText(view: WebView?) {
        val js = """
            (function() {
                function apply() {
                    if (!window.location.pathname.startsWith("/direct")) return;
                    document.querySelectorAll('span').forEach(el => {
                        if (el.textContent.trim() === "Likes") {
                            let target = el.closest('div.html-div') || el;
                            target.style.display = "none";
                        }
                    });
                }
                const observer = new MutationObserver(apply);
                observer.observe(document.body, { childList: true, subtree: true });
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun disableVideoScroll(view: WebView?) {
        val js = """
            (function() {
                function apply() {
                    document.querySelectorAll('div[aria-label="Video player"]').forEach(el => {
                        el.style.setProperty("touch-action", "none", "important");
                    });
                }
                const observer = new MutationObserver(apply);
                observer.observe(document.body, { childList: true, subtree: true });
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun blockSuggestedForYou(view: WebView?) {
        val js = """
            (function() {
                function apply() {
                    document.querySelectorAll('span').forEach(span => {
                        if (span.textContent.trim() === "Suggested for you") {
                            let p = span.parentElement;
                            while(p && p.tagName !== 'DIV') p = p.parentElement;
                            if(p) p.style.display = "none";
                        }
                    });
                }
                const observer = new MutationObserver(apply);
                observer.observe(document.body, { childList: true, subtree: true });
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun hideSharedContainerBlock(view: WebView?) {
        val js = """
        (function() {
            // Helper function to find the closest common ancestor of two nodes
            function getClosestCommonAncestor(node1, node2) {
                const parents = new Set();
                let curr = node1;
                
                // Build a path from the first node up to the root
                while (curr) {
                    parents.add(curr);
                    curr = curr.parentElement;
                }
                
                // Trace up from the second node until we hit a match in the path
                curr = node2;
                while (curr) {
                    // Return the first match that is a <div>
                    if (parents.has(curr) && curr.tagName && curr.tagName.toLowerCase() === 'div') {
                        return curr;
                    }
                    curr = curr.parentElement;
                }
                return null;
            }

            function apply() {
                // Find all spans (or elements) containing the exact text
                // We use Array.from to iterate and filter based on exact text content
                const noPostsNodes = Array.from(document.querySelectorAll('span, div')).filter(el => 
                    el.childNodes.length === 1 && 
                    el.childNodes[0].nodeType === Node.TEXT_NODE && 
                    el.textContent.trim() === 'No posts yet'
                );
                
                const seeAllNodes = Array.from(document.querySelectorAll('span, div, a')).filter(el => 
                    el.childNodes.length === 1 && 
                    el.childNodes[0].nodeType === Node.TEXT_NODE && 
                    el.textContent.trim() === 'See all'
                );

                // If either text is missing from the DOM, there's nothing to hide yet
                if (noPostsNodes.length === 0 || seeAllNodes.length === 0) return;

                // Compare pairs to find their shared container
                noPostsNodes.forEach(noPostsNode => {
                    seeAllNodes.forEach(seeAllNode => {
                        const commonContainer = getClosestCommonAncestor(noPostsNode, seeAllNode);
                        
                        // Hide it if we found a shared container that hasn't been hidden yet
                        if (commonContainer && !commonContainer.dataset.permanentlyHidden) {
                            
                            // Optional Safety Guard: Prevent hiding the entire website body if they are far apart
                            // If the common container has too many children, it might be the main feed wrapper
                            // if (commonContainer.id === 'react-root' || commonContainer.tagName === 'MAIN') return;

                            commonContainer.style.setProperty("display", "none", "important");
                            commonContainer.style.setProperty("visibility", "hidden", "important");
                            commonContainer.dataset.permanentlyHidden = "true";
                        }
                    });
                });
            }

            // Run once immediately
            apply();

            // Set up the observer to catch dynamically loaded React content
            const observer = new MutationObserver((mutations) => {
                const hasAddedNodes = mutations.some(m => m.addedNodes.length > 0);
                if (hasAddedNodes) {
                    apply();
                }
            });
            
            observer.observe(document.body, { childList: true, subtree: true });
        })();
    """.trimIndent()
        view?.evaluateJavascript(js, null)
    }


    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}